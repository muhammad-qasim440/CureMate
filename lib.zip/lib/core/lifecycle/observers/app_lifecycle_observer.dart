import 'dart:async';
import 'package:curemate/core/utils/debug_print.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:firebase_database/firebase_database.dart';
import '../../../src/shared/chat/providers/chatting_auth_providers.dart';

final appLifecycleObserverProvider = Provider<AppLifecycleObserver>((ref) {
  return AppLifecycleObserver(ref);
});

class AppLifecycleObserver with WidgetsBindingObserver {
  final Ref ref;
  final DatabaseReference _db = FirebaseDatabase.instance.ref();
  Timer? _pingTimer;

  AppLifecycleObserver(this.ref) {
    WidgetsBinding.instance.addObserver(this);
    // _waitForUserAndStart();
  }

  void _waitForUserAndStart() async {
    logDebug('Waiting for user to load in lifecycle observer...');
    while (ref.read(currentUserProvider).value == null) {
      await Future.delayed(const Duration(milliseconds: 100));
    }

    final user = ref.read(currentUserProvider).value!;
    logDebug('User loaded in lifecycle: ${user.uid}');
    await _updateStatus(user.uid, true);
    _setOnDisconnect(user.uid);
    _startPinging(user.uid);
  }


  void _setOnDisconnect(String uid) {
    _db.child('Users/$uid/status').onDisconnect().set({
      'isOnline': false,
      'lastSeen': ServerValue.timestamp,
      'ping': ServerValue.timestamp,
    }).catchError((e) {
    });
  }

  Future<void> _updateStatus(String uid, bool isOnline) async {
    try {
      final userRef = _db.child('Users/$uid');
      final statusRef = userRef.child('status');
      final userSnapshot = await userRef.get();
      if (!userSnapshot.exists) {
        await userRef.set({
          'status': {
            'isOnline': isOnline,
            'lastSeen': ServerValue.timestamp,
            'ping': ServerValue.timestamp,
          },
        });
      } else if (!(await statusRef.get()).exists) {
        await statusRef.set({
          'isOnline': isOnline,
          'lastSeen': ServerValue.timestamp,
          'ping': ServerValue.timestamp,
        });
      } else {
        await statusRef.update({
          'isOnline': isOnline,
          'lastSeen': ServerValue.timestamp,
          'ping': ServerValue.timestamp,
        });
      }
    } catch (e) {
      logDebug('Error updating status: $e at ${DateTime.now()}');
    }
  }

  void _startPinging(String uid) {
    _pingTimer?.cancel();
    _pingTimer = Timer.periodic(const Duration(seconds: 10), (_) async {
      try {
        logDebug('i am from _startPinging');

        await _db.child('Users/$uid/status').update({
          'isOnline': true,
          'lastSeen': ServerValue.timestamp,
          'ping': ServerValue.timestamp,
        });
      } catch (e) {
        logDebug('Error updating status: $e at ${DateTime.now()}');
      }
    });
  }

  void _stopPinging() {
    _pingTimer?.cancel();
    _pingTimer = null;
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final user = ref.read(currentUserProvider).value;
    if (user == null) {
      logDebug('from didchange $user');
      return;
    }

    try {
      if (state == AppLifecycleState.resumed) {
        logDebug('i am from resumed');
        // _updateStatus(user.uid, true);
        // _startPinging(user.uid);
      } else if (state == AppLifecycleState.paused ||
          state == AppLifecycleState.detached ||
          state == AppLifecycleState.inactive) {
        // _updateStatus(user.uid, false);
        _stopPinging();
      }
    } catch (e) {
      logDebug('Error handling lifecycle state change: $e at ${DateTime.now()}');
    }
  }

  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _stopPinging();
  }
}