Future<void> wait(Duration duration) async {
  await Future.delayed(duration);
}
