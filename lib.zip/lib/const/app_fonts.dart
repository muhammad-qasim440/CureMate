class AppFonts{
  static const String poppins = 'Poppins';
  static const String bangers = 'Bangers';
  static const String rubik = 'Rubik';
  static const String rubikMedium = 'Rubik-Medium';
}