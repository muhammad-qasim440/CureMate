import 'package:flutter/cupertino.dart';

class FontSizes {
  final BuildContext context;

  FontSizes(this.context);

  double _scale(double size) {

    return size * MediaQuery.of(context).size.width / 400;
  }

  double get size8 => _scale(8);
  double get size10 => _scale(10);
  double get size12 => _scale(12);
  double get size13 => _scale(13);
  double get size14 => _scale(14);
  double get size15 => _scale(15);
  double get size16 => _scale(16);
  double get size17 => _scale(17);
  double get size18 => _scale(18);
  double get size20 => _scale(20);
  double get size22 => _scale(22);
  double get size24 => _scale(24);
  double get size26 => _scale(26);
  double get size28 => _scale(28);
  double get size30 => _scale(30);
  double get size32 => _scale(32);
  double get size34 => _scale(34);
  double get size40 => _scale(40);
  double get size41 => _scale(41);
  double get size42 => _scale(42);
  double get size43 => _scale(43);
  double get size44 => _scale(44);
  double get size45 => _scale(45);
  double get size46 => _scale(46);
  double get size47 => _scale(47);
  double get size48 => _scale(48);
  double get size49 => _scale(49);
  double get size50 => _scale(50);
  double get size51 => _scale(51);
  double get size52 => _scale(52);
  double get size53 => _scale(53);
  double get size54 => _scale(54);
  double get size55 => _scale(55);
  double get size56 => _scale(56);
  double get size57 => _scale(57);
  double get size58 => _scale(58);
  double get size59 => _scale(59);
  double get size60 => _scale(60);
  double get size61 => _scale(61);
  double get size62 => _scale(62);
  double get size63 => _scale(63);
  double get size64 => _scale(64);
  double get size65 => _scale(65);
  double get size66 => _scale(66);
  double get size67 => _scale(67);
  double get size68 => _scale(68);
  double get size69 => _scale(69);

}