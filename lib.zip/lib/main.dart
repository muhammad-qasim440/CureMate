import 'package:curemate/src/app.dart';

void main() => App.initilizationAndRun();
