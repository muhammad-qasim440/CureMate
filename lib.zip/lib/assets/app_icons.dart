class AppIcons{
  static const String baseIconPath= 'assets/icons/';
  static const String appSplashIc = '${baseIconPath}app_splash_ic.svg';
  static const String appSplashBlackIc = '${baseIconPath}app_splash_black_ic.svg';
}