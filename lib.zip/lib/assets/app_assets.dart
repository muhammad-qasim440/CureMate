class AppAssets {
  AppAssets._();

  static const baseImagePath = 'assets/images/';
  static const doctorImg1 = '${baseImagePath}doctor1_img.png';
  static const doctorImg2 = '${baseImagePath}doctor2_img.png';
  static const doctorImg3 = '${baseImagePath}doctor3_img.png';
}
